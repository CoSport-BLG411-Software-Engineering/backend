
INSERT INTO chainTable VALUES (1, 'All Fit', 4, 80)
INSERT INTO gymTable VALUES (15, 'Maslak', 29, '06.00', '23.59', 1)
INSERT INTO gymTable VALUES (22, 'Kanyon', 32, '06.00', '23.59', 1)
INSERT INTO personalTrainerTable VALUES (1, "ahmet", "zoraki", 22, "male", 15, "basketball")
INSERT INTO personalTrainerTable VALUES (2, "mehmet", "zoraki", 25, "male", 22, "footbal")
INSERT INTO facilityTable VALUES (1, "basketball", 15)
INSERT INTO facilityTable VALUES (2, "basketball", 22)

